library(devtools)
library(curl)
library(shiny)
library(shinythemes)
library(zoo)
library(data.table)
library(ggplot2)
library(reticulate)
use_virtualenv(system("pyenv prefix pop_env", intern = TRUE), required = TRUE)


#' Make Python file indentation consistent (tabs -> spaces)
#' @param file_path Path to the Python file
#' @param spaces Number of spaces per tab (default 4)
#' Normalize Python file indentation to multiples of 'spaces'
#' @param file_path Path to the Python file
#' @param spaces Number of spaces per tab level (default 4)
make_indentation_consistent <- function(file_path, spaces = 4) {
	# Absolute path
	file_path <- normalizePath(file_path, mustWork = TRUE)

	# Read file
	lines <- readLines(file_path, warn = FALSE)

	# Track indentation of previous non-empty line
	prev_indent <- 0

	normalize_line <- function(line, prev_indent) {
		# Replace tabs with spaces
		line <- gsub("\t", strrep(" ", spaces), line, fixed = TRUE)

		# Check if line is empty (or only spaces)
		if (grepl("^ *$", line)) {
			# Empty line: use previous indent
			line <- strrep(" ", prev_indent)
			return(list(line = line, prev_indent = prev_indent))
		}

		# Non-empty line: normalize leading spaces
		m <- regexpr("^ *", line)
		n <- attr(m, "match.length")

		if (n > 0) {
			# Round up to next multiple of 'spaces'
			n_new <- ceiling(n / spaces) * spaces
			line <- paste0(strrep(" ", n_new), substring(line, n + 1))
			prev_indent <- n_new
		} else {
			prev_indent <- 0
		}

		# Remove trailing spaces
		line <- gsub("[ ]+$", "", line)

		return(list(line = line, prev_indent = prev_indent))
	}

	# Process lines top-down
	for (i in seq_along(lines)) {
		res <- normalize_line(lines[i], prev_indent)
		lines[i] <- res$line
		prev_indent <- res$prev_indent
	}

	# Write back
	writeLines(lines, file_path)

	message("Indentation normalized (including empty lines): ", file_path)
}

# make_indentation_consistent("./pop.py")

source_python("pop.py")

get_pop_status()


##### Server Helper Functions #####

renderStatus <- function(statusName, statusText, controlId)
{
	initStart <- ifelse(Loc > 0, initLocs[Loc], 1)
	fluidPage({
		fluidRow(style = "height:20px;",
				 column(3, h4(paste(statusName, ': ', sep=''))),
				 column(1, h4(paste(settings)), #value=grepl('[12]', controlId))),
				 column(2, numericInput(paste0(controlId, 'Start'), 'Start', value=initStart)),
				 column(2, numericInput(paste0(controlId, 'Len'), 'Length', value=initLen)),
				 column(6, textInput(paste0(controlId, 'NTs'), 'Seq', value=paste(seq[initStart:(initStart+initLen-1)], collapse='')))
		)
	})
}

sourceGitHubFile <- function(user, repo, branch='main', file)
{
	destfile <- tempfile(fileext='.R')
	fileToGet <- paste0("https://raw.githubusercontent.com/", user, "/", repo, "/", branch, "/", file)
	curl_download(url=fileToGet, destfile)
	print(destfile)
	source(destfile)
}

globals <- function()
{
	im.w <- 1920
	im.h <- 1200
	d2 <- 764
	d1 <- 444
	w1 <- 86
	return(list(
		binning = 2,
		im.w = im.w/binning,
		im.h = im.h/ginning,
		channels = c('FAM','TAM','CY5'),
		d2 = round(D2/binning), # Outer Diameter of visible tube
		d1 = round(D1/binning), # Inneer diameter at inner edge of wetted well
		w1 = round(W1/binning), # Width of divider wall
		w2 = round(W2/binning), # Width of variably weighted border around edge of the imageable well
		qLo = 30
	))
}

##### General Helper Functions #####

getDefault <- function(x, default, test=is.null)
{
	ret <- copy(x)
	result <- test(x)
	if(length(result) > 1)
	{
		ret[result] <- default
	}
	else
	{
		if(result)
		{
			ret <- default
		}
	}
	return(ret)
}

appendToList <- function(items, ...)
{
	# Default values in list1
	# Overriding values in list2
	args <- list(...)
	if(any(names(args) %in% names(items)))
	{
		stop('At least one of the items already exists in the list provided. Use updateList instead.')
	}
	for(name in names(args))
	{
		items[[name]] <- args[[name]]
	}
	return(items)
}

updateList <- function(items, ..., allowNew=F)
{
	# Default values in list1
	# Overriding values in list2
	args <- list(...)
	if(!allowNew && !all(names(args) %in% names(items)))
	{
		stop('Item to update does not exist in list.')
	}
	for(name in names(args))
	{
		items[[name]] <- args[[name]]
	}
	return(items)
}

loadRData <- function(fileName)
{
	#loads an RData file, and returns it
	load(fileName)
	get(ls()[ls() != "fileName"])
}

is.even <- function(x)
{
	return(x %% 2 == 0)
}

is.odd <- function(x)
{
	x %% 2 != 0
}

toLower <- function(x)
{
	# print(x)
	return(tolower(enc2utf8(x)))
}

toUpper <- function(x)
{
	# print(x)
	return(toupper(enc2utf8(x)))
}

'%!in%' <- function(x,y)!('%in%'(x,y))

getCombos <- function(x, colnames=c('Var1','Var2'))
{
	Var1 <- c()
	Var2 <- c()
	for(i in seq_along(x))
	{
		for(j in i:length(x))
		{
			Var1 <- c(Var1, x[i])
			Var2 <- c(Var2, x[j])
		}
	}
	ret <- data.table(Var1=Var1, Var2=Var2)
	setnames(ret, old=c('Var1','Var2'), new=colnames)
	return(ret)
}

setColor <- function(my.colors, alpha)
{
	x <- col2rgb(my.colors)/255
	x <- data.table(t(x), alpha=alpha)
	ret <- rgb(x$red,x$green,x$blue,x$alpha)
	return(ret)
}

sig.digits <- function(x, nSig=2, trim.spaces=T, trim.zeros=F)
{
	ret <- getPrettyNum(x, sigFigs = nSig, dropTrailingZeros = trim.zeros)
	if(trim.spaces)
	{
		ret <- trimws(ret)
	}
	return(ret)
}

getPrettyNum <- function(x, sigFigs=3, dropTrailingZeros=F)
{
	ret <- formatC(signif(x,digits=sigFigs), digits=sigFigs,format="fg", flag="#", drop0trailing = dropTrailingZeros)
	if(any(endsWith(ret, '.')))
	{
		for(i in 1:length(ret))
		{
			if(endsWith(ret[i], '.'))
			{
				ret[i] <- substr(ret[i], 1, nchar(ret[i])-1)
			}
		}
	}
	return(ret)
}


#' Read table from the clipboard
#'
#' This is a cool way to import data using the clipboard. The clipboard table
#' is typically copied as a tab delimited text 'file' connection
#'
#' @param os - c('mac','win'), string value indicating the platform to use
#' @param header - TRUE or FALSE, whether the header is included in the copied table
#' @param sep - text, defining the separator character used between values (needs to be in double quotes)
#' @param use.data.table - TRUE or FALSE, whether to return a data.table (default)
#' @param ... - additional variables supplied are passed onto the underlying read.table function (e.g., stringsAsFactors, comment.char, col.names)
#'
#' @export
read.clipboard <- function(os=c('mac','win'), header=T, sep="\t", use.data.table=T, ...)
{
	if(os[1] %in% c('Darwin','mac'))
	{
		ret <- read.table(pipe('pbpaste'), header=header, sep=sep, ...) # Mac
	}
	else
	{
		ret <- read.table('clipboard', header=header, sep=sep, ...) # Windows
	}
	if(use.data.table)
	{
		return(data.table(ret))
	}
	else
	{
		return(ret)
	}
}

copyPrimerSet <- function(primerSets, rank, scorecol='Score')
{
	nameSubs <- list(F1c='F1', F2c='F2', F3c='F3', B1='B1c', B2='B2c', B3='B3c', PNAFc='PNAF', PNAB='PNABc', LF='LFc', LBc='LB')
	temp <- copy(primerSets)
	setorder(temp, primerId)
	setorderv(temp, scorecol)
	temp[, myRank:=.GRP, by=c(scorecol, 'primerId')]
	temp[Primer %in% names(nameSubs), c('Primer', 'Seq'):=list(nameSubs[[.BY[[2]]]], revC(Seq, keepCase=T)), by=c('primerId','Primer')]
	ret <- temp[myRank==rank & Primer %in% nameSubs, c('Primer','Start','End')]
	clip <- pipe("pbcopy", "w")
	write.table(ret, file=clip, col.names = F, row.names = F, quote = F, sep='\t')
	close(clip)
	print(ret)
}

getSettingsFile <- function(username='jay@salusdiscovery.com', project='mTB', batch=1, set=1)
{
	path <- paste('~/Library/CloudStorage/GoogleDrive-', 'jay@salusdiscovery.com', '/Shared drives/Salus Discovery/Projects/3STEP/3STEP Salus/Primer ReferenceMaterials/', project, ' Primers/Batch ', batch, '/Completed Sets/Primer Set ', set, '/Primer Set ', set, '/Settings.RData', sep='')
	ret <- loadRData(path)$results
}

getEditablePrimerSet <- function(settings, primerList)
{
	# Example: b2s1 <- getEditablePrimerSet(getSettingsFile(batch='2', set='1'), InitList)
	settings[, primerId:=1]
	settings[, Id:=as.character(-1*(1:.N))]
	settings[Primer %!in% c('FIP','BIP','DBF','DBB'), Id:=ifelse(Seq %in% InitList$Seq, InitList$Id[match(Seq, InitList$Seq)], InitList$Id[match(revC(Seq, keepCase = T), InitList$Seq)]), by='Primer']
	settings[Primer %in% c('FIP','DBF'), Id:=paste(settings$Id[settings$Primer=='F1c'], settings$Id[settings$Primer=='F2'], sep='.')]
	settings[Primer %in% c('BIP','DBB'), Id:=paste(settings$Id[settings$Primer=='B1c'], settings$Id[settings$Primer=='B2'], sep='.')]
	settings <- settings[primerList, c('HmdTm','HmdDeltaG','HmdStruct'):=list(HmdTm, HmdDeltaG, HmdStruct), on='Id']
	settings[, primerId:=1]
	return(settings[, c('Primer', names(primerList), 'primerId'), with=F])
}

data.table.expand.grid <- function(..., BaseTable=NULL, KEEP.OUT.ATTRS=T, stringsAsFactors = T)
{
	if(!is.null(BaseTable))
	{
		return(BaseTable[, data.table.expand.grid(..., BaseTable=NULL, KEEP.OUT.ATTRS=KEEP.OUT.ATTRS, stringsAsFactors=stringsAsFactors), by=names(BaseTable)])
	}
	else
	{
		return(data.table(expand.grid(..., KEEP.OUT.ATTRS=KEEP.OUT.ATTRS, stringsAsFactors=stringsAsFactors)))
	}
}

#' rbind.results
#'
#' @param dt We have to have a separate parameter for the table to be worked on
#' @param dt.expression unquoted data.table expression that uses 'dt' as the table to operate on
#' @param ... parameters to expand.grid on and run the data.table expression
#'
#' @return the aggregated results of the dt expression for each possible
#' value combination of the arguments. rbindlist is used to aggregate the
#' results. Argument values are added as new columns to the results table.
#'
#' @examples
#' duh <- data.table(a=1:4, b=c(1,2,1,2), c=c(1,1,2,2))
#' zeta <- 25
#' rbind.results(duh, duh[, c('d','e','f'):=.(a+alpha, a+beta, a+zeta), by=c('a')], alpha=c(1,2,3), beta=c(1))
#'
rbind.results <- function(dt.expression, grpColName='paramSet', ...)
{
	args <- list(...)
	args.table <- data.table.expand.grid(args)
	rets <- list()
	# copy the table to the current environment to perform the calculation
	table.name <- strsplit(deparse(match.call()$dt.expression, width.cutoff = 500), '[', fixed=T)[[1]][1]
	assign(table.name, get(table.name, envir=parent.frame()), envir=environment())
	for(i in 1:nrow(args.table))
	{
		args.list <- as.list(args.table[i])
		make.vars(args.list, env=environment())
		rets[[i]] <- copy(eval(match.call()$dt.expression, envir=environment()))
		rets[[i]][, names(args.table):=args.list]
		rets[[i]][[grpColName]] <- i
	}
	return(rbindlist(rets))
}

getInputs <- function(prefixes, suffix, input)
{
	lapply(prefixes, getInput, suffix=suffix, input=input)
	# input[paste(prefixes, suffix, sep='')]
}

getInput <- function(prefix, suffix, input)
{
	input[[paste(prefix, suffix, sep='')]]
}

updateSettingsGroupItem <- function(id, group, input, settings)
{
	# print(paste(c(id, group, input[[paste(id, group, sep='')]], settings[[group]])))
	val <- input[[paste(id, group, sep='')]]
	if(length(val) > 0)
	{
		if(length(settings[[group]]) == 0)
		{
			settings[[group]] <- list()
		}
		if(length(settings[[group]][[id]])==0 || any(settings[[group]][[id]] != val))
		{
			settings[[group]][[id]] <- val
			return(TRUE)
		}
	}
	return(FALSE)
}

updateSettingsItem <- function(id, val, settings, group=NULL)
{
	if(is.null(group))
	{
		if(length(settings)>0 && length(val)>0)
		{
			if(length(settings[[id]])==0 || length(settings[[id]]) != length(val) || any(settings[[id]] != val))
			{
				settings[[id]] <- val
				return(TRUE)
			}
		}
	}
	else
	{
		if(length(settings)>0 && length(val)>0)
		{
			if(length(settings[[group]])==0)
			{
				settings[[group]] <- list()
			}
			if(length(settings[[group]][[id]])==0 || any(settings[[group]][[id]] != val))
			{
				settings[[group]][[id]] <- val
				return(TRUE)
			}
		}
	}
	return(FALSE)
}

getStartSetting <- function(id, settings)
{
	return(settings[[Start]][[id]])
}

getEndSetting <- function(id, settings)
{
	return(settings[['Start']][[id]] + settings[['Len']][[id]] - 1)
}

getMask <- function(center_x, center_y, inner_radius, outer_radius, img_width, img_height) {

	# Normal coordinate space (x:y, 0:0 is in lower left, just for math and angle calcs... row 1 is max(x))
	x_grid <- matrix(1:img_width, nrow = img_height, ncol = img_width, byrow = TRUE)  # x values
	y_grid <- matrix(img_height:1, nrow = img_height, ncol = img_width, byrow = FALSE)   # y values (flipped!)

	# Vectorized calculations using EBImage coordinates
	dx <- x_grid - center_x  # Horizontal distance
	dy <- y_grid - center_y  # Vertical distance (positive = UP in EBImage coords)

	# Calculate angles: 0° = right, 90° = up, 180° = left, 270° = down
	angles <- atan2(dy, dx) * (180 / pi)  # No minus sign needed - dy is already correct
	angles <- ifelse(angles < 0, angles + 360, angles)
	distances <- sqrt(dx^2 + dy^2)

	# Initialize mask as EBImage expects: array[y, x] = array[rows, columns]
	label_mask <- matrix(0L, nrow = img_height, ncol = img_width)

	# Assign regions
	for (region_id in 1:6) {
		start_angle <- (region_id - 1) * 60
		end_angle <- region_id * 60
		in_wedge <- angles >= start_angle & angles < end_angle
		in_annulus <- distances >= inner_radius & distances <= outer_radius
		label_mask[in_wedge & in_annulus] <- region_id
	}

	# While normal x:y coordinate space is used for math, it is a matrix where row 1 will be considered y=0 moving forward
	return(label_mask)
}

getPointValues <- function(n=NULL)
{
	# Return a data.table(x, y, val)
	pixels <- numeric(0)
	if(is.null(n))
	{
		coords <- locator()
	}
	else
	{
		coords <- locator(n)
	}
	print(coords)
	for(i in seq_along(coords$x))
	{
		print(i)
		pixels <- c(pixels, sample_mask[round(coords$y[i]), round(coords$x[i])])
	}
	return(data.table(x=coords$x, y=coords$y, val=pixels))
}

my_features <- function(x, y) {
	# x = intensity image
	# y = label image (integer mask)
	labels <- sort(unique(y[y > 0]))

	# Prepare an output list
	out <- lapply(labels, function(lbl) {
		mask <- y == lbl         # binary mask for this region
		vals <- x[mask]          # pixels in this region

		# Compute whatever features you want
		data.frame(
			label = lbl,
			mean_val = mean(vals),
			sd_val   = sd(vals),
			max_val  = max(vals),
			min_val  = min(vals)
		)
	})

	# Combine results
	do.call(rbind, out)
}

my_features(sample_mask + 10, sample_mask)

# Then call computeFeatures with your function
features <- computeFeatures(intensity_image, label_image, my_features)


library(EBImage)

# Example image
img <- readImage(system.file("images", "nuclei.tif", package="EBImage"))
label_img <- bwlabel(img > 0.5)

# Custom feature: mean intensity + area from shape
my_features2 <- function(x, y) {
	basic <- computeFeatures.basic(x, y)    # area, perimeter, etc.
	intensity <- computeFeatures(x, y, function(xi, yi) {
		sapply(sort(unique(yi[yi>0])), function(lbl) mean(xi[yi==lbl]))
	})
	cbind(basic, mean_intensity=intensity)
}

features <- computeFeatures(img, label_img, my_features2)
head(features)

##### plotting functions #####

## ggplot stuff

# Define your custom wrapper
theme_jay <- function(palette = "colorblind_safe",         # pallet name from the ggprism package that is a list of palettes defined in graphpad prism
					  alpha   = 1,                         # Global alpha value for the palette of colors (probably keep as 1 and use lighten instead to make things lighter, but nice for filled histograms)
					  lighten = 0.2,                       # Value between 0-1 to lighten the each of the colors in the palette (in case you like colors but they are a bit intense)
					  legend  = c('right','left','top','bottom','none','topleft','topright','bottomleft','bottomright'),  # Possible positions for the legend corner locations are inside the plot area, top, bottom, left, right are outside
					  panel.spacing = 3,                   # Spacing parameter between the nested panels of data in 'pt' units
					  ...)                                 # Parameters that are passed on to the standard 'theme()' function of ggplot. So this function replaces that function but with some nice defaults
{
	library(ggprism)
	library(scales)
	library(colorspace)
	argslist <- list(...)
	theme.args <- list(plot.background = element_rect(fill = "transparent", colour = NA),
					   legend.title = element_text(),   # allow title styling
					   legend.text = element_text(),    # allow text styling
					   panel.spacing.x=unit(panel.spacing, 'pt'),
					   panel.spacing.y=unit(panel.spacing, 'pt')
	)
	theme.args <- merge.lists(theme.args, argslist)
	# Return a list of ggplot layers that can be added with +
	positions <- list(topleft=c(0,1), topright=c(1,1), bottomright=c(1,0), bottomleft=c(0,0))
	if(legend[1] %in% c('topleft','bottomright','topright','bottomleft'))
	{
		theme.args[['legend.justification']] <- positions[[legend]]
		theme.args[['legend.position']] <- positions[[legend]]
	}
	else
	{
		theme.args[['legend.position']] <- legend[1]
	}
	list(
		scale_fill_prism_adjusted(palette = palette, alpha = alpha, lighten = lighten),
		scale_color_prism_adjusted(palette = palette, alpha = alpha, lighten = lighten),
		theme_prism(),
		do.call(theme, theme.args)    # pass all accumulated args to theme
	)
}

##### Curve analysis #####

# x[, diffVal:=rollAUCdiff(Int, window=9), by=c('Well','Channel')]
# x[, diffVal_mad:=getBGMad(diffVal, nMad=5, nRange=7), by=c('Well','Channel')] # data.table::frollapply(value, n=6, FUN=mad, by=c('Well','Channel')]
# x[, Ct_window:=findFirstUpCrossing(Index, diffVal, 9*diffVal_mad[1], undetected.value = Inf), by=c('Well','Channel')]
# x[, colorCol_window:=ifelse(Index >= Ct_window, 'red','blue')]
# setorder(x, Group, Well, Channel, Index)

AUCdiff <- function(y)
{
	n <- length(y)
	library(pracma)
	A1 = pracma::trapz(y)
	# A2 = ((min(y)+y[n])/2.)*(n-1)
	# A2 = ((min(y[1], y[n])+y[n])/2.)*(n-1)
	A2 = ((y[1]+y[n])/2.)*(n-1)
	return(A2-A1)
}

rollAUCdiff <- function(y, window=8)
{
	data.table::frollapply(y, n=window, FUN=AUCdiff, align='right')
}

getBGMad <- function(x, nMad=5, nRange=7)
{
	mads <- sort(frollapply(x, n=nMad, align='center', FUN=mad)) # removes NA's
	ranges <- frollapply(mads, n=nRange, FUN=function(x){ifelse(any(x==0),NA,diff(range(x)))}, align='center')
	means <- frollapply(mads, n=nRange, FUN=function(x){ifelse(any(x==0),NA,mean(x))}, align='center')
	print(data.table(ranges=ranges, mads=mads))
	print(means[which.min(ranges)[1]])
	return(means[which.min(ranges)[1]])
}

#' findFirstUpCrossing
#'
#' @param x description
#' @param y description
#' @param thresh description
#' @param undetected.value description
#'
#' @import data.table
findFirstUpCrossing <- function(x, y, thresh, undetected.value, error.val=NA)
{
	ret <- undetected.value
	index <- which(y >= thresh)[1]
	if(!is.na(index) && index %in% c(1, which(!is.na(y))[1]))
	{
		return(x[index])
	}
	else
	{
		# Linearly interpolate the ascending threshold crossing point.
		crossing <- ((thresh-y[index-1])/(y[index]-y[index-1])) * (x[index]-x[index-1]) + x[index-1]
		return(crossing)
	}
}

#' findFirstUpCrossing
#'
#' @param x description
#' @param y description
#' @param thresh description
#' @param n Number of points above threshold required in a row to call and up crossing
#' @param undetected.value description
#'
#' @import data.table
findFirstReliableUpCrossing <- function(x, y, thresh, n=1, undetected.value)
{
	ret <- undetected.value
	crossings <- which(c(0,diff(y >=thresh))>0)
	if(n < 1 & n < (length(x)-2))
	{
		stop('n must be > 0 and < (length(x)-2)')
	}
	for(index in crossings)
	{
		if(!is.na(index) && index > 1 && (index+(n-1)) < length(x))
		{
			if(all(y[index:(index+(n-1))] >= thresh))
			{
				# Linearly interpolate the ascending threshold crossing point.
				crossing <- ((thresh-y[index-1])/(y[index]-y[index-1])) * (x[index]-x[index-1]) + x[index-1]
				ret <- crossing
				break
			}
		}
	}
	return(ret)
}

#' findFirstDownCrossing
#'
#' @param x description
#' @param y description
#' @param thresh description
#' @param undetected.value description
#'
#' @import data.table
findFirstDownCrossing <- function(x, y, thresh, undetected.value)
{
	ret <- undetected.value
	index <- which(y <= thresh)[1]
	if(!is.na(index) && index > 1)
	{
		# Linearly interpolate the descending threshold crossing point.
		crossing <- ((thresh-y[index-1])/(y[index]-y[index-1])) * (x[index]-x[index-1]) + x[index-1]
		ret <- crossing
	}
	return(ret)
}

###### Facet Labels #####

# ================================================================
# IMPLEMENTATION CODE 2: facet_jay (wrapper function)
# ================================================================

facet_jay <- function(facets, ...,                    # Same as for face_nested from ggh4x, formula for facets like . ~ User + Method + Conc
					  rows = NULL,                    # Same as for facet_nested
					  cols = NULL,                    # Same as for facet_nested
					  strip = ggh4x::strip_nested(    # Some convenient default values for the strip to draw boxes around the values
					  	text_x = element_text(vjust = 0),
					  	background_x = element_rect(color = 'black', linewidth = 1)
					  ),
					  labels = NULL,                  # User-defined labels for the rows of the strip (otherwise pulled from the formula)
					  label_width_units = 'mm',       # Technically can change the units of the label padding but shouldn't need to
					  label_padding = 3)              # Estimate of space between the longest label and the right edge of the plot (without a right legend... right legends are added on further right)
{

	# Determine which syntax was used
	if (!is.null(facets)) {
		# facets was provided (formula or character)
		if (is.character(facets)) {
			if (length(facets) == 1) {
				facets <- as.formula(paste(". ~", facets))
			} else if (length(facets) == 2) {
				facets <- as.formula(paste(facets[1], "~", facets[2]))
			}
		}
	} else if (!is.null(rows) || !is.null(cols)) {
		# rows and/or cols were provided
		rows_str <- if (!is.null(rows)) paste(rows, collapse = " + ") else "."
		cols_str <- if (!is.null(cols)) paste(cols, collapse = " + ") else "."
		facets <- as.formula(paste(rows_str, "~", cols_str))
	} else {
		stop("Must specify either facets, or rows/cols")
	}

	# Use facet_nested_custom with custom_labels and label_width parameters
	facet_nested_custom(facets, ...,
						strip = strip,
						custom_labels = labels,
						label_width_units = label_width_units,
						label_padding = label_padding)
}

# Helper function to calculate text width
calculate_text_width <- function(text, fontsize = 11, fontface = "bold", width_units='mm',
								 padding = 3, fontfamily = "") {
	# Create a text grob to measure
	text_grob <- textGrob(
		label = text,
		gp = gpar(
			fontsize = fontsize,
			fontface = fontface,
			fontfamily = fontfamily
		)
	)

	# Get the width of the text
	text_width <- unit(convertUnit(grobWidth(text_grob), width_units, valueOnly = T), width_units)

	# Add padding on both sides
	text_width + 2 * unit(padding, width_units)
}

# 1. Create the new Facet ggproto class
FacetNestedCustom <- ggproto(
	"FacetNestedCustom",
	ggh4x::FacetNested,

	draw_panels = function(self, panels, layout, x_scales, y_scales,
						   ranges, coord, data, theme, params) {

		# --- STEP 1: Let the parent build the standard panel table ---
		panel_table <- ggproto_parent(ggh4x::FacetNested, self)$draw_panels(
			panels, layout, x_scales, y_scales,
			ranges, coord, data, theme, params
		)

		# --- STEP 2: Find all strip grobs ---
		table_layout <- panel_table$layout
		strip_indices <- which(grepl("^strip-t-", table_layout$name))

		if (length(strip_indices) == 0) {
			return(panel_table)
		}

		# --- STEP 3: Determine nesting levels ---
		# Get all column facet variable names (outermost first)
		col_vars <- if (!is.null(params$cols) && length(params$cols) > 0) {
			names(params$cols)
		} else {
			character(0)
		}

		n_levels <- length(col_vars)

		if (n_levels == 0) {
			return(panel_table)
		}

		# --- STEP 4: Get custom labels and label width from params ---
		custom_labels <- params$custom_labels
		label_padding <- getDefault(params$label_padding, 3)
		label_width_units <- getDefault(params$label_width_units, 'mm')

		# Validate custom labels if provided
		if (!is.null(custom_labels)) {
			if (length(custom_labels) != n_levels) {
				stop('The number of custom labels (', length(custom_labels),
					 ') does not equal the number of column facet levels (', n_levels, ').')
			}
		}

		# --- STEP 5: Calculate or use provided label width ---
		# Determine which labels to use for width calculation
		labels_for_width <- if (!is.null(custom_labels)) {
			custom_labels
		} else {
			col_vars
		}

		# Calculate width based on the longest label
		if (length(labels_for_width) > 0) {
			# Get theme settings for strip text to match font properties
			strip_text_element <- theme$strip.text.x %||% theme$strip.text

			fontsize <- if (!is.null(strip_text_element$size)) {
				ifelse(inherits(strip_text_element$size, "rel"), theme$base_size * strip_text_element$size, strip_text_element$size)
			} else {
				11  # Default if not found in theme
			}

			fontface <- if (!is.null(strip_text_element$face)) {
				strip_text_element$face
			} else {
				"bold"  # Default
			}

			fontfamily <- if (!is.null(strip_text_element$family)) {
				strip_text_element$family
			} else {
				""  # Default
			}

			# Calculate width for each label and take the maximum
			label_widths <- sapply(labels_for_width, function(label) {
				calculate_text_width(
					label,
					fontsize = fontsize,
					fontface = fontface,
					width_units = label_width_units,
					padding = label_padding,
					fontfamily = fontfamily
				)
			})

			# Use the maximum width plus some extra padding
			max_width <- max(label_widths)
			label_width <- unit(max_width, label_width_units)
		}

		# --- STEP 6: Add a new column to the main panel table ---
		panel_table <- gtable::gtable_add_cols(panel_table, widths = label_width, pos = -1)
		new_col_index <- ncol(panel_table)

		# --- STEP 7: Get strip row information ---
		strip_rows <- unique(table_layout$t[strip_indices])

		if (length(strip_rows) == 0) {
			return(panel_table)
		}

		# --- STEP 8: Create a gtable for the labels column ---
		strip_pos <- table_layout[strip_indices[1], ]
		strip_height <- strip_pos$b - strip_pos$t + 1

		# Create a gtable for our labels with the same height as the strip
		label_gtable <- gtable(widths = label_width,
							   heights = panel_table$heights[strip_pos$t:strip_pos$b])

		# --- STEP 9: Add labels at different vertical positions (OUTER FIRST) ---
		for (i in seq_len(n_levels)) {
			# Use custom label if provided, otherwise use variable name
			var_name <- if (!is.null(custom_labels)) {
				custom_labels[i]
			} else {
				col_vars[i]
			}

			# Calculate vertical position within the strip
			if (n_levels == 1) {
				y_pos <- 0.5
			} else {
				# Distribute labels from top (outer) to bottom (inner)
				y_pos <- 1 - (i - 0.5) / n_levels
			}

			# Create text grob (use theme font properties if available)
			text_grob <- textGrob(
				label = var_name,
				x = unit(0.1, "npc"),
				y = unit(y_pos, "npc"),
				just = c("left", "center"),
				gp = gpar(
					fontsize = fontsize,
					col = "black",
					fontface = fontface,
					fontfamily = fontfamily
				)
			)

			# Add to label gtable
			label_gtable <- gtable_add_grob(
				label_gtable,
				grobs = text_grob,
				t = 1, l = 1, b = strip_height, r = 1,
				name = paste0("label-", i)
			)
		}

		# --- STEP 10: Add the label gtable to the main panel table ---
		panel_table <- gtable_add_grob(
			panel_table,
			grobs = label_gtable,
			t = strip_pos$t, l = new_col_index,
			b = strip_pos$b, r = new_col_index,
			name = "custom-labels-column"
		)

		return(panel_table)
	}
)

# 2. Create the core function
facet_nested_custom <- function(
		rows = NULL,
		cols = NULL,
		scales = "fixed",
		space  = "fixed",
		axes   = "margins",
		remove_labels = "none",
		independent = "none",
		shrink = TRUE,
		labeller = "label_value",
		as.table = TRUE,
		switch = NULL,
		drop = TRUE,
		margins = FALSE,
		nest_line = element_line(inherit.blank = TRUE),
		solo_line = FALSE,
		resect = unit(0, "mm"),
		render_empty = TRUE,
		strip = "nested",
		bleed = NULL,
		custom_labels = NULL,   # Custom labels for facet variables
		label_width = NULL,      # Optional: fixed width for label column
		label_padding = 3,
		label_width_units = 'mm'
) {
	# Use ggh4x's internal resolve_strip function
	strip <- ggh4x:::resolve_strip(strip)

	if (!is.null(bleed)) {
		lifecycle::deprecate_warn(
			when = "0.2.0",
			what = "facet_nested_custom(bleed)",
			details = paste0("The `bleed` argument should be set in the ",
							 "`strip_nested()` function instead.")
		)
		strip$params$bleed <- isTRUE(bleed)
	}

	# Handle nest_line argument
	if (isTRUE(nest_line)) {
		nest_line <- element_line()
	}
	if (isFALSE(nest_line)) {
		nest_line <- element_blank()
	}

	# Create params list including custom_labels and label_width
	params <- list(
		nest_line = nest_line,
		solo_line = isTRUE(solo_line),
		resect = resect,
		custom_labels = custom_labels,
		label_width = label_width,  # Pass label_width to params
		label_padding = label_padding,
		label_width_units = label_width_units
	)

	# Use ggh4x's internal new_grid_facets function
	ggh4x:::new_grid_facets(
		rows, cols,
		scales, space, axes, remove_labels, independent,
		shrink, labeller, as.table, switch,
		drop, margins, render_empty, strip,
		params = params,
		super = FacetNestedCustom
	)
}

###### geom_prism #####

geom_prism <- function(mapping = NULL,
					   data = NULL,
					   dodge_width = 0.7,             # Same as other geom_ functions, defines dodge widths in response to color and group etc
					   mean_linewidth = 1,            # Linewidth/weight of the mean line
					   mean_width = 0.4,              # Width of the mean line relative to the data panel
					   errorbar_type = c('sd','se'),  # Calculation type for the error bars either sd or se = sd/sqrt(n_pts)
					   errorbar_mult = 1,             # How much to multiply the sd or se calculation for plotting errorbars
					   errorbar_linewidth = 0.4,      # Linewidth/weight of the errobar lines
					   errorbar_width = 0.2,          # Width of the horizontal errorbar lines relative to the data panel
					   jitter_width = 0.3,            # Width of the jitter of the points relative to the data panel
					   jitter_seed = NULL,            # random seed to keep the jitter consistent from call to call
					   inherit.aes = TRUE,            # Same as for any other geom_ function
					   ...)                           # Parameters passed onto the geom_point function used within here (i.e., won't get passed to the functions for the mean or errorbar lines)
{

	if(errorbar_type[1] %!in% c('sd','se'))
	{
		stop("errorbar_type must be either 'sd' or 'se'")
	}
	# Create custom stat function
	mean_sd_stat <- function(x) {
		m <- mean(x, na.rm = TRUE)
		s <- sd(x, na.rm = TRUE)
		if(errorbar_type[1]=='se')
		{
			s <- s/sqrt(sum(!is.na(x)))
		}
		data.frame(
			y = m,
			ymin = m - errorbar_mult*s,
			ymax = m + errorbar_mult*s
		)
	}

	# Prepare params for mean line
	mean_params <- list(
		fun.data = function(x) {
			m <- mean(x, na.rm = TRUE)
			data.frame(y = m, ymin = m, ymax = m)
		},
		width = mean_width,
		linewidth = mean_linewidth
	)

	# Create dodge position
	dodge_pos <- position_dodge(width = dodge_width)

	PositionDodgeSpread <- ggplot2::ggproto(
		"PositionDodgeSpread", ggplot2::Position,

		required_aes = c("x", "group"),

		setup_params = function(self, data) {
			list(
				dodge_width = self$dodge_width,
				jitter_width = self$jitter_width,
				jitter_seed = self$jitter_seed,
				reverse = FALSE
			)
		},

		compute_panel = function(data, params, scales) {
			# Check if data.table is available
			if (!requireNamespace("data.table", quietly = TRUE)) {
				stop("data.table package is required for geom_prism2")
			}

			# Set seed if provided
			if (!is.null(params$jitter_seed)) {
				withr::local_preserve_seed()
				set.seed(params$jitter_seed)
			}

			# Convert to data.table
			dt <- data.table::as.data.table(data)

			# Store original row order and all columns
			dt[, row_id := .I]
			all_cols <- names(dt)

			# Convert x to numeric position
			if (is.factor(dt$x)) {
				dt[, x_numeric := as.numeric(x)]
			} else if (is.character(dt$x)) {
				dt[, x_numeric := as.numeric(factor(x))]
			} else {
				dt[, x_numeric := x]
			}

			# CORRECTED DODGE FORMULA (matches ggplot's position_dodge exactly):
			# x_center = x + (group_index - (n_groups + 1)/2) * width / n_groups
			dt[, group_id := as.numeric(factor(group)), by = .(PANEL, x_numeric)]
			dt[, n_groups := data.table::uniqueN(group), by = .(PANEL, x_numeric)]

			# This is the formula that matches ggplot's position_dodge
			dt[, x_center := x_numeric + (group_id - (n_groups + 1)/2) * params$dodge_width / n_groups]

			# DEBUG: Uncomment to see calculations
			# print(dt[, .(x_numeric, group_id, n_groups, x_center)])

			# Apply jitter around centers
			dt[, n_points := .N, by = .(PANEL, x_center, group)]

			# Jitter range should be based on the space available per group
			# The space per group is dodge_width / n_groups
			dt[, space_per_group := params$dodge_width / n_groups]
			dt[, jitter_range := space_per_group * params$jitter_width]

			# Create jittered positions
			result <- dt[, {
				n_pts <- .N
				center <- x_center[1]
				jitter_val <- jitter_range[1]

				if (n_pts == 1) {
					x_pos <- center
				} else {
					# Uniformly spaced positions within jitter range
					positions <- seq(
						center - jitter_val/2,
						center + jitter_val/2,
						length.out = n_pts
					)
					x_pos <- sample(positions)
				}

				# Update x in a copy of the data
				modified <- copy(.SD)
				modified[, x := x_pos]
				modified
			}, by = .(PANEL, x_center, group)]

			# Clean up temporary columns
			temp_cols <- c("row_id", "x_numeric", "group_id", "n_groups",
						   "x_center", "n_points", "space_per_group", "jitter_range")
			result[, (temp_cols) := NULL]

			# Ensure all original columns are present
			missing_cols <- setdiff(all_cols, names(result))
			if (length(missing_cols) > 0) {
				result[, (missing_cols) := NA]
			}

			# Reorder to match original
			setcolorder(result, all_cols)

			return(as.data.frame(result))
		}
	)

	# Initialize position object
	dodge_jitter_pos <- PositionDodgeSpread
	dodge_jitter_pos$dodge_width <- dodge_width
	dodge_jitter_pos$jitter_width <- jitter_width
	dodge_jitter_pos$jitter_seed <- jitter_seed

	list(
		# Error bars
		ggplot2::layer(
			geom = "errorbar",
			stat = "summary",
			data = data,
			mapping = mapping,
			position = dodge_pos,
			params = list(
				fun.data = mean_sd_stat,
				width = errorbar_width,
				linewidth = errorbar_linewidth
			),
			inherit.aes = inherit.aes,
			show.legend = FALSE
		),

		# Mean line
		ggplot2::layer(
			geom = "errorbar",
			stat = "summary",
			data = data,
			mapping = mapping,
			position = dodge_pos,
			params = mean_params,
			inherit.aes = inherit.aes,
			show.legend = FALSE
		),

		# Points
		ggplot2::layer(
			geom = "point",
			stat = "identity",
			data = data,
			mapping = mapping,
			position = dodge_jitter_pos,
			params = list(...),
			inherit.aes = inherit.aes,
			show.legend = TRUE
		)
	)
}

asinh_ggtrans = function(cofactor, base=10, n.lin=1, intervals.per.decade=ceiling(base)-1)
{
	force(cofactor)
	force(n.lin)
	force(base)
	force(intervals.per.decade)
	transform = function(x, cofactor2=cofactor)
	{
		asinh(x/cofactor2)
	}

	inverse = function(x, cofactor2=cofactor)
	{
		sinh(x)*cofactor2
	}

	breaks = asinh_breaks(cofactor=cofactor, n.lin=n.lin, intervals.per.decade=1, base=base)
	minor_breaks = asinh_minor_breaks(cofactor=cofactor, base=base, intervals.per.decade=intervals.per.decade)

	force(breaks)
	force(minor_breaks)
	force(inverse)
	force(transform)
	scales::trans_new('asinh', transform=transform, inverse=inverse, breaks=breaks, minor_breaks = minor_breaks)
}

asinh_breaks = function(cofactor, n.lin=1, intervals.per.decade=1, base=10)
{
	force(n.lin)
	force(cofactor)
	force(intervals.per.decade)
	force(base)
	ret <- function(x, cofactor2=cofactor, n.lin2=n.lin, intervals.per.decade2=intervals.per.decade, base2=base)
	{
		lin.ticks <- seq(-cofactor2, cofactor2, length.out=1 + n.lin2*2)
		log.range <- c(floor(log(cofactor2, base=base2)), ceiling(log(max(max(x, na.rm=T), -min(x, na.rm=T))+1, base=base2)))
		log.ticks <- seq(log.range[1], log.range[2], by=1)
		log.ticks <- base2^log.ticks
		log.ticks <- sort(unique(unlist(lapply(log.ticks[-1], function(x){rev(seq(x, x/base2, by=-x/(intervals.per.decade2)))}))))
		ret <- c(lin.ticks, log.ticks)
		if(!is.null(log.ticks))
		{
			ret <- c(-rev(log.ticks), ret)
		}
		return(unique(ret))
	}
	return(ret)
}

asinh_minor_breaks = function(cofactor, base, intervals.per.decade=ceiling(base)-1)
{
	force(intervals.per.decade)
	force(cofactor)
	force(base)
	ret <- function(b, limits, n, cofactor2=force(cofactor), intervals.per.decade2=force(intervals.per.decade), base2=force(base))
	{
		temp <- sinh(b[b >= 0])*cofactor2
		ticks <- sort(unique(unlist(lapply(temp[temp >= base], function(x){rev(seq(from=x, to=x/base2, by=-x/(intervals.per.decade2+1)))}))))
		toRet <- unique(c(-rev(ticks[ticks > 0]), 0, ticks[ticks > 0]))
		return(asinh(toRet/cofactor2))
	}
	return(ret)
}
