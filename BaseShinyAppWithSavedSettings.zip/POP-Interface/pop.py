import sys
import os
import importlib.metadata

def get_pop_status():
    temp1 = 66.3
    temp2 = 54.5
    mag = 49.8
    us = "Off"
    ret = {
        "Temp1": temp1,
        "Temp2": temp2,
        "Mag": mag,
        "US": us
    }
    return(ret)
    
# pkgs = [(dist.metadata["Name"], dist.version) for dist in importlib.metadata.distributions()]
# 
# for name, version in sorted(pkgs):
#     print(f"{name}=={version}")

print('Importing of Python Helper Functions Complete.')

# Instructions
#
# https://k0nze.dev/posts/install-pyenv-venv-vscode/#:~:text=Installing%20pyenv%201%20Windows%2010%2F11.%20Create%20a%20new,and%20packages%20necessary%20for%20building%20Python%20from%20scratch.?msclkid=6d65c550b5e711ecab14022d27ebb3cd
#
# brew install pyenv
# brew install pyenv pyenv-virtualenv
#
# .zshrc file

# export PYENV_ROOT="$HOME/.pyenv"
# export PATH="$PYENV_ROOT/bin:$PATH"
# eval "$(pyenv init -)"
# eval "$(pyenv virtualenv-init -)"
#
# Set up python and virtual environment
# pyenv install 3.12
# pyenv virtualenv 3.12 pop-env
# 
# pip3 install numpy
# pip3 install pandas
# pip3 install pip-autoremove
#
# pip-autoremove <package-to-remove> -y



