# create_defaults.R - Run this ONCE to create default files

library(fs)

# Create defaults directory
dir_create("defaults")



d2 <- 764
d1 <- 444
w1 <- 86

# 1. INSTRUMENT DEFAULTS
defaults <- list(
	channels = c('FAM','TAM','CY5'),
	camera = list(
		binning = 2,
		gain = 1.0,
		pixel_size_um = 6.5,
		bit_depth = 8,
		suffix = '.bmp',
		folder = 'raw',
		im.w = constants$im.w,
		im.h = constants$im.h
	),
	FAM = list(
		exposure_ms = 100,
		AUC_window = 9,
		MAD_window = 7,
		range_window = 5,
		thresh_mult = 9
	),
	TAM = list(
		exposure_ms = 100,
		AUC_window = 9,
		MAD_window = 7,
		range_window = 5,
		thresh_mult = 9
	),
	CY5 = list(
		exposure_ms = 100,
		AUC_window = 9,
		MAD_window = 7,
		range_window = 5,
		thresh_mult = 9
	)
)
	analysis = list(
		qHi = 95, # Upper quantile threshold (inclusive below)
		qLo = 25, # Lower quantile threshold (inclusive above)
		d1 = 444/constants$binning, # inner mask dia in terms of fraction of image height
		d2 = 764/constants$im.h, # outer mask dia in terms of fraction of image height
		w1 = 86/constants$im.h
	)
	file_format = list(
		type = "TIFF",
		compression = "none",
		save_metadata = TRUE,
		naming_scheme = "{date}_{time}_{frame}.tiff"
	),
	validation = list(
		version = "1.0.0",
		created = Sys.time(),
		hash = digest::digest("instrument_defaults_v1")
	)
)

# Save as read-only RDS
saveRDS(instrument_defaults, "defaults/instrument_defaults.rds")

# 2. PROCESSING DEFAULTS
processing_defaults <- list(
	roi = list(
		x1 = 0,
		y1 = 0,
		x2 = 1024,
		y2 = 768,
		auto_detect = FALSE
	),
	filters = list(
		gaussian_size = 3,
		median_size = 3,
		apply_flat_field = TRUE,
		dark_correction = TRUE
	),
	analysis = list(
		threshold_method = "otsu",
		min_particle_size = 10,
		max_particle_size = 1000,
		measure_intensity = TRUE,
		measure_morphology = TRUE
	),
	output = list(
		save_processed_images = TRUE,
		save_statistics = TRUE,
		plot_format = "png",
		dpi = 300
	)
)

saveRDS(processing_defaults, "defaults/processing_defaults.rds")

# 3. MAKE FILES READ-ONLY (Platform-specific)
if (.Platform$OS.type == "windows") {
	# Windows
	system('attrib +R defaults\\*.rds')
} else {
	# Unix/Linux/Mac
	Sys.chmod("defaults/instrument_defaults.rds", mode = "0444")  # read-only
	Sys.chmod("defaults/processing_defaults.rds", mode = "0444")
}

message("✅ Default files created and set to read-only")
