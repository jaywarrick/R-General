# Initialize empty settings and settings type containers
settings <- reactiveValues()

# server.R (updated)
server <- function(input, output, session) {

	# -----------------------------
	# Setup shinyFiles for folder selection
	# -----------------------------
	volumes <- c("App Directory" = normalizePath('./'),
				 Home = fs::path_home(),
				 "R Installation" = R.home(),
				 getVolumes()())

	# Reactive value to store the last status query
	status_data <- reactiveVal(NULL)

	session$onFlushed(function() {
		bind_all_settings(session, input, settings, input_types)
	}, once = TRUE)

	# Observe the button and update the reactive value
	observeEvent(input$check_status_btn, {
		status <- get_pop_status()  # query the instrument
		print('Done getting status')
		status_data(status)
	})

	# Render UI outputs using the reactive status_data
	output$Temp1 <- renderUI({
		req(status_data())
		renderStatus(
			"Well-Temp Target/Actual",
			paste(sig.digits(input$Temp1, nSig = 3), "/", sig.digits(status_data()$Temp1, nSig = 3),  '[°C]')
		)
	})

	output$Temp2 <- renderUI({
		req(status_data())
		renderStatus(
			"Wax-Temp Target/Actual",
			paste(sig.digits(input$Temp2, nSig = 3), "/", sig.digits(status_data()$Temp2, nSig = 3),  '[°C]')
		)
	})

	output$Mag <- renderUI({
		req(status_data())
		renderStatus("Magnet Pos.", paste(status_data()$Mag, '[mm]'))
	})

	output$US <- renderUI({
		req(status_data())
		renderStatus("Ultrasonics", status_data()$US)
	})

	# Save folder chooser
	shinyDirChoose(input, "folder_btn", roots = volumes, session = session)
	# Backup folder chooser
	shinyDirChoose(input, "backup_btn", roots = volumes, session = session)

	# Update text input & settings reactively for Save folder
	observeEvent(input$folder_btn, {
		req(input$folder_btn)
		selected <- parseDirPath(volumes, input$folder_btn)
		if (!is.null(selected)) {
			updateTextInput(session, "save_directory", value = selected)
			settings$paths$save_directory <- selected
		}
	})

	# Update text input & settings reactively for Backup folder
	observeEvent(input$backup_btn, {
		req(input$backup_btn)
		selected <- parseDirPath(volumes, input$backup_btn)
		if (!is.null(selected)) {
			updateTextInput(session, "backup_directory", value = selected)
			settings$paths$backup_directory <- selected
		}
	})

	# Trigger Save As modal
	observeEvent(input$save_as_btn, {
		# List existing .rds files
		existing_files <- list.files("user_settings", pattern = "\\.rds$", full.names = FALSE)

		showModal(modalDialog(
			title = "Save Settings As…",
			textInput(
				"save_as_name",
				"Filename (without .rds):",
				value = paste0("settings_", format(Sys.time(), "%Y%m%d_%H%M%S"))
			),
			if(length(existing_files) > 0){
				tagList(
					p("Existing files:"),
					tags$ul(lapply(existing_files, tags$li))
				)
			},
			footer = tagList(
				modalButton("Cancel"),
				actionButton("confirm_save_as", "Save", class = "btn-primary")
			)
		))
	})

	# Handle Save As confirmation
	observeEvent(input$confirm_save_as, {
		req(input$save_as_name)

		# Construct file path
		filename <- paste0(input$save_as_name, ".rds")
		file_path <- file.path("user_settings", filename)

		# Check if file exists
		if (file.exists(file_path)) {
			showModal(modalDialog(
				title = "File Already Exists",
				paste0("A settings file named '", filename, "' already exists. Overwrite?"),
				footer = tagList(
					modalButton("Cancel"),
					actionButton("confirm_overwrite", "Overwrite", class = "btn-danger")
				)
			))
		} else {
			save_settings(settings, file_path)
			showNotification(paste("💾 Saved as:", filename), type = "message", duration = 3)
			removeModal()
		}
	})

	# Handle overwrite confirmation
	observeEvent(input$confirm_overwrite, {
		req(input$save_as_name)
		filename <- paste0(input$save_as_name, ".rds")
		file_path <- file.path("user_settings", filename)

		save_settings(settings, file_path)
		showNotification(paste("💾 Overwritten:", filename), type = "warning", duration = 3)
		removeModal()
	})


	# Load button
	observeEvent(input$load_btn, {
		if (dir.exists("user_settings")) {
			files <- list.files("user_settings", pattern = "\\.rds$", full.names = TRUE)
			if (length(files) > 0) {
				file_info <- file.info(files)
				display_names <- paste(basename(files),
									   " (", format(file_info$mtime, "%Y-%m-%d %H:%M"), ")",
									   sep = "")
				showModal(modalDialog(
					title = "Load Settings File",
					size = "m",
					selectInput("load_choice", "Choose file:",
								choices = setNames(files, display_names)),
					footer = tagList(
						modalButton("Cancel"),
						actionButton("confirm_load", "Load", class = "btn-primary")
					)
				))
			} else {
				showModal(modalDialog(
					title = "No Files Found",
					"No settings files found in user_settings/ directory.",
					footer = modalButton("OK")
				))
			}
		} else {
			showModal(modalDialog(
				title = "Directory Not Found",
				"user_settings/ directory does not exist.",
				footer = modalButton("OK")
			))
		}
	})

	observeEvent(input$confirm_load, {
		req(input$load_choice)
		if (load_settings(session, settings, input$load_choice)) {
			showNotification("✅ Settings loaded successfully", type = "message", duration = 3)
		} else {
			showNotification("❌ Failed to load settings", type = "error", duration = 3)
		}
		removeModal()
	})

	# observeEvent(input$confirm_save_as, {
	# 	req(input$save_as_name)
	#
	# 	# Same directory as current.rds
	# 	base_dir <- dirname("user_settings/current.rds")
	# 	filename <- paste0(input$save_as_name, ".rds")
	# 	file_path <- file.path(base_dir, filename)
	#
	# 	save_settings(file_path)
	#
	# 	showNotification(
	# 		paste("💾 Saved as:", filename),
	# 		type = "message",
	# 		duration = 3
	# 	)
	#
	# 	removeModal()
	# })

	# -----------------------------
	# OUTPUT DISPLAYS
	# -----------------------------

	# # Display current settings
	# output$settings_view <- renderPrint({
	# 	current <- reactiveValuesToList(settings)
	# 	current$metadata <- NULL
	# 	cat("=== CURRENT SETTINGS ===\n\n")
	# 	str(current, max.level = 2, vec.len = 2)
	# })
	output$settings_view <- renderPrint({
		current <- reactiveValuesToNestedList(settings)
		current$metadata <- NULL
		cat("=== CURRENT SETTINGS ===\n\n")
		str(current, max.level = 2, vec.len = 2)
	})

	# Status Info
	output$status_info <- renderText({
		last_saved <- if (!is.null(settings$metadata$saved_at)) {
			format(settings$metadata$saved_at, "%H:%M:%S")
		} else {
			"Never"
		}

		save_dir <- if (!is.null(settings$paths$save_directory)) {
			settings$paths$save_directory
		} else {
			getwd()  # fallback default
		}

		paste(
			"📊 Status:\n",
			"Last saved: ", last_saved, "\n",
			"Images: ", settings$acquisition$duration_sec / settings$acquisition$interval_sec, "\n",
			"Save to: ", basename(save_dir), "\n",
			"Auto-process: ", ifelse(settings$processing$auto_process, "ON", "OFF"),
			sep = ""
		)
	})


	# -----------------------------
	# SESSION CLEANUP
	# -----------------------------
	session$onSessionEnded(function() {
		message("Put anything you want here for when the app is closed")
	})
}
