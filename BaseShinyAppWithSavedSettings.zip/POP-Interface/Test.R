# Load required packages for visualization
library(grid)     # For grid.raster - fast image display
library(EBImage)  # For as.Image conversion if needed
library(data.table)

# ------------------------------------------------------------
# STEP 1: FAST, VECTORIZED MASK CREATION (EBImage x,y coordinates)
# ------------------------------------------------------------
create_polar_label_mask_ebimage <- function(center_x, center_y, inner_radius, outer_radius, img_width, img_height) {
	# Vectorized coordinate grids using EBImage convention
	# x (horizontal) varies along columns, y (vertical) varies along rows
	x_grid <- matrix(1:img_width, nrow = img_height, ncol = img_width, byrow = TRUE)  # x values
	y_grid <- matrix(img_height:1, nrow = img_height, ncol = img_width, byrow = FALSE)   # y values (flipped!)

	# Vectorized calculations using EBImage coordinates
	dx <- x_grid - center_x  # Horizontal distance
	dy <- y_grid - center_y  # Vertical distance (positive = UP in EBImage coords)

	# Calculate angles: 0° = right, 90° = up, 180° = left, 270° = down
	angles <- atan2(dy, dx) * (180 / pi)  # No minus sign needed - dy is already correct
	angles <- ifelse(angles < 0, angles + 360, angles)
	distances <- sqrt(dx^2 + dy^2)

	# Initialize mask as EBImage expects: array[y, x] = array[rows, columns]
	label_mask <- matrix(0L, nrow = img_height, ncol = img_width)

	# Assign regions
	for (region_id in 1:6) {
		start_angle <- (region_id - 1) * 60
		end_angle <- region_id * 60
		in_wedge <- angles >= start_angle & angles < end_angle
		in_annulus <- distances >= inner_radius & distances <= outer_radius
		label_mask[in_wedge & in_annulus] <- region_id
	}

	return(label_mask)
}

# ------------------------------------------------------------
# STEP 2: VISUALIZE THE MASK IN RSTUDO
# ------------------------------------------------------------
visualize_label_mask <- function(label_mask, title = "Polar Label Mask") {
	# Convert integer label mask to RGB colors for display
	# Create a color palette: background + 6 distinct colors
	color_palette <- c(
		"black",      # 0 = background
		"red",        # 1 = region 1
		"green3",     # 2 = region 2
		"blue",       # 3 = region 3
		"gold",       # 4 = region 4
		"magenta",    # 5 = region 5
		"cyan"        # 6 = region 6
	)

	# Map each label (0-6) to its corresponding color
	# Note: +1 because R indices start at 1 (label 0 → color_palette[1])
	rgb_matrix <- color_palette[label_mask + 1]
	dim(rgb_matrix) <- dim(label_mask)

	# Display directly in RStudio's plot pane
	grid::grid.newpage()
	grid::grid.raster(rgb_matrix, interpolate = FALSE)

	# Add title as a separate viewport
	grid::grid.text(title, y = 0.95, gp = grid::gpar(fontsize = 14, col = "white"))

	# Optional: Print region summary to console
	cat("Mask Summary:\n")
	cat("Dimensions:", nrow(label_mask), "x", ncol(label_mask), "\n")
	for (i in 1:6) {
		cat(sprintf("Region %d: %d pixels\n", i, sum(label_mask == i)))
	}
}

# ------------------------------------------------------------
# STEP 3: TEST THE COMPLETE WORKFLOW
# ------------------------------------------------------------
# Create a sample mask (~4 MP: 2000 x 2000)
sample_mask <- create_polar_label_mask_ebimage(
	center_x = 1100,
	center_y = 1000,
	inner_radius = 300,
	outer_radius = 800,
	img_width = 2200,
	img_height = 2000
)

# Visualize it immediately
# visualize_label_mask(sample_mask, title = "6-Region Polar Mask")

# ------------------------------------------------------------
# BONUS: QUICK INLINE VIEW (For quick checks while coding)
# ------------------------------------------------------------
# Option 1: Simple grayscale preview (fastest)
quick_preview <- function(mask) {
	# Normalize to 0-1 range for grayscale display
	preview <- mask / max(mask)
	grid::grid.raster(preview, interpolate = FALSE)
}

# Option 2: Using EBImage's display (interactive)
if(require(EBImage)) {
	ebimage_preview <- function(mask) {
		# Apply transpose to counteract EBImage's transpose
		img <- EBImage::as.Image(t(mask) / max(mask))
		display(img)
	}
	# Usage: ebimage_preview(sample_mask)
}

quick_preview(sample_mask)
ebimage_preview(sample_mask)


vals <- getPointValues()

#
#
#
#
# library(EBImage)
#
# # Create a tiny 3x3 test image with obvious values
# test_img <- Image(matrix(rep(1:500, each=1000), nrow=500, ncol=1000, byrow=TRUE))
# # This creates:
# # Row 1 (value 1): [1, 1, 1]  ← Should be TOP if displayed normally
# # Row 2 (value 2): [2, 2, 2]
# # Row 3 (value 3): [3, 3, 3]  ← Should be BOTTOM if displayed normally
#
# display(test_img/500, method="raster")
# cat("FIRST, click on the DARKEST row (should be value 3 if bottom, value 1 if top)...\n")
# pt1 <- locator(n=1)
# cat(sprintf("Clicked at: x=%.2f, y=%.2f\n", pt1$x, pt1$y))
#
# cat("\nNOW, click on the LIGHTEST row...\n")
# pt2 <- locator(n=1)
# cat(sprintf("Clicked at: x=%.2f, y=%.2f\n", pt2$x, pt2$y))
#
# # Check what the actual values are
# cat("\nMatrix values (row, column):\n")
# for(r in 1:3) {
# 	cat(sprintf("Row %d: ", r))
# 	for(c in 1:3) {
# 		cat(imageData(test_img)[r, c], " ")
# 	}
# 	cat("\n")
# }
#
#
#
