# ui.R
library(shiny)
library(shinyFiles)  # For folder selection
source('UIFunctions.R')

ui <- fluidPage(

	# Application title
	titlePanel("Instrument Controller"),

	sidebarLayout(
		sidebarPanel(
			width = 4,

			h4('Controls', style = "color: blue;"),
			actionButton('check_status_btn', 'Check Status'),
			actionButton('run_btn', 'Run Test'),
			selectInput2('program', 'Program', choices = list('Heat+US+Magnet+Imaging','Heat','US','Magnet','Imaging','Heat+US','US+Magnet','US+Heat','Heat+Imaging','US+Heat+Magnet')),

			h4('Status', style = "color: blue;"),
			uiOutput('Temp1'),
			uiOutput('Temp2'),
			uiOutput('Mag'),
			uiOutput('US'),
		),

		mainPanel(
			width = 8,
			tabsetPanel(
				tabPanel(
					"Main",
					h4("Live Settings View"),
					verbatimTextOutput("settings_view")
				),
				tabPanel(
					"Results",
					h4("Display Settings"),
					selectInput("colormap", "Colormap",
								choices = c("gray", "hot", "jet", "viridis", "plasma"),
								selected = "gray"),
					sliderInput("brightness", "Brightness",
								min = 0.1, max = 3.0, value = 1.0, step = 0.1),
					sliderInput("contrast", "Contrast",
								min = 0.1, max = 3.0, value = 1.0, step = 0.1),
					checkboxInput2("show_scalebar", "Show Scalebar", value = TRUE),
					textInput2("scalebar_units", "Scalebar Units", value = "µm"),
					numericInput2("pixel_size", "Pixel Size (µm)",
								 value = 6.5, min = 0.1, max = 100, step = 0.1)
				),
				tabPanel(
					"Settings",

					fluidPage(
						fluidRow(
							column(width=6,
								   h4('Instrument Settings', style = "color: blue;"),
								   actionButton('save_as_btn', 'Save...'),
								   actionButton('load_btn', 'Load...'),


								   hr(),

								   h4('Heater Settings', style = "color: blue;"),
								   numericInput2('Temp1', 'Well Temperature Setting [°C]',
								   			 value = 70.1, min=60, max=75, step=0.1),
								   numericInput2('Temp2', 'Wax Temperature Setting [°C]',
								   			 value = 70.1, min=60, max=75, step=0.1),

								   h4('US Settings', style = "color: blue;"),
								   numericInput2('us_n_search', '# of Freq. Sweeps',
								   			  value = 3, min=0, max=10, step=1),
								   numericInput2('us_duty', 'Duty Cycle',
								   			  value = 100, min=1, max=100, step=5),

								   h4('Magnet Settings', style = "color: blue;"),
								   h6('(height 0-50mm, ~0 for extraction, >35 for imaging)'),
								   numericInput2('z_home', 'Home Position [mm]',
								   			  value = 50, min=0, max=50, step=0.1),
								   numericInput2('z_top', 'Top Extraction Position [mm]',
								   			  value = 0, min=0, max=50, step=0.1),
								   numericInput2('z_pulse', 'Pulse Bottom Position [mm]',
								   			  value = 5, min=0, max=50, step=0.1),
								   numericInput2('n_pulse', '# of Pulses Per Set',
								   			  value = 5, min=0, max=50, step=0.1),
								   numericInput2('n_set', '# of Pulse Sets',
								   			  value = 5, min=0, max=50, step=0.1),
								   numericInput2('delay_pulse', 'Single Pulse Time [s]',
								   			  value = 0.2, min=0.1, max=1, step=0.05),
								   numericInput2('delay_set', 'Delay Between Sets [s]',
								   			  value = 2, min=0.1, max=10, step=0.1),
								   numericInput2('speed_pulse', 'Pulse Travel Speed [%]',
								   			  value = 5, min=0, max=50, step=0.1),
								   numericInput2('speed_transfer', 'Bead Transfer Speed [%]',
								   			  value = 5, min=0, max=50, step=0.1),
								   numericInput2('speed_home', 'Homing Speed [%]',
								   			  value = 5, min=0, max=50, step=0.1),

								   h4('Mask Settings', style = "color: blue;"),
								   h6('(px units BEFORE binning and x=y=0 at topleft of image)'),
								   numericInput2('center_x', 'Outer Tube Diameter [px]',
								   			 value=const$camera$im.w, min = 0, max = const$camera$im.w, step=1),
								   numericInput2('center_y', 'Outer Tube Diameter [px]',
								   			 value=const$camera$im.h, min = 0, max = const$camera$im.h, step=1),
								   numericInput2('d1', 'Outer Tube Diameter [px]',
								   			 value=764, min = 750, max = 780, step=1),
								   numericInput2('d2', 'Outer Tube Diameter [px]',
								   			 value=444, min = 420, max = 470, step=1),
								   numericInput2('w1', 'Divider Wall Width [px]',
								   			 value=86, min = 75, max = 100, step=1),
								   numericInput2('w2', 'Outer Tube Diameter [px]',
								   			 value=40, min = 0, max = 80, step=1),

								   h4('Directory Settings', style = "color: blue;"),
								   textInput2('raw_image_directory', 'Raw Image Directory',
								   		  value = file.path(getwd(), 'raw_images')),
								   shinyDirButton('image_dir_btn', 'Choose Folder...',
								   			   'Select save directory', FALSE),
								   textInput2('results_directory', 'Results Directory',
								   		  value = file.path(getwd(), 'results')),
								   shinyDirButton('results_dir_btn', 'Choose Folder...',
								   			   'Select backup directory', FALSE)
							),
							column(width=6,
								   h4('FAM Settings', style = "color: blue;"),
								   numericInput2('FAM_exposure', 'Exposure (ms)',
								   			 value = 100, min = 1, max = 10000, step = 1),
								   numericInput2('FAM_qHi', 'Lowest Quantile Pixel',
								   			 value = 10, min = 0, max = 90, step = 1),
								   numericInput2('FAM_qLo', 'Highest Quantile Pixel',
								   			 value = 95, min = 10, max = 100, step = 1),
								   numericInput2('FAM_AUC_window', 'AUC window',
								   			 value = 9, min = 5, max = 15, step = 1),
								   numericInput2('FAM_MAD_window', 'MAD window',
								   			 value = 7, min = 5, max = 13, step = 1),
								   numericInput2('FAM_range_window', 'Range window',
								   			 value = 5, min = 5, max = 15, step = 1),
								   numericInput2('FAM_thresh_mult', 'SNR Threshold Multiplier',
								   			 value = 9.0, min = 1.0, max = 30, step = 0.1),

								   h4('TAM Settings', style = "color: blue;"),
								   numericInput2('TAM_exposure', 'Exposure (ms)',
								   			 value = 100, min = 1, max = 10000, step = 1),
								   numericInput2('TAM_qHi', 'Lowest Quantile Pixel',
								   			 value = 10, min = 0, max = 90, step = 1),
								   numericInput2('TAM_qLo', 'Highest Quantile Pixel',
								   			 value = 95, min = 10, max = 100, step = 1),
								   numericInput2('TAM_AUC_window', 'AUC window',
								   			 value = 9, min = 5, max = 15, step = 1),
								   numericInput2('TAM_MAD_window', 'MAD window',
								   			 value = 7, min = 5, max = 13, step = 1),
								   numericInput2('TAM_range_window', 'Range window',
								   			 value = 5, min = 5, max = 15, step = 1),
								   numericInput2('TAM_thresh_mult', 'SNR Threshold Multiplier',
								   			 value = 9.0, min = 1.0, max = 30, step = 0.1),

								   h4('CY5 Settings', style = "color: blue;"),
								   numericInput2('CY5_exposure', 'Exposure (ms)',
								   			 value = 100, min = 1, max = 10000, step = 1),
								   numericInput2('CY5_qHi', 'Lowest Quantile Pixel',
								   			 value = 10, min = 0, max = 90, step = 1),
								   numericInput2('CY5_qLo', 'Highest Quantile Pixel',
								   			 value = 95, min = 10, max = 100, step = 1),
								   numericInput2('CY5_AUC_window', 'AUC window',
								   			 value = 9, min = 5, max = 15, step = 1),
								   numericInput2('CY5_MAD_window', 'MAD window',
								   			 value = 7, min = 5, max = 13, step = 1),
								   numericInput2('CY5_range_window', 'Range window',
								   			 value = 5, min = 5, max = 15, step = 1),
								   numericInput2('CY5_thresh_mult', 'SNR Threshold Multiplier',
								   			 value = 9.0, min = 1.0, max = 30, step = 0.1)
							)
						)
					)
				)
			)
		)
	)
)
