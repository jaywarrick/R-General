# list.of.packages <- c('devtools','curl','shiny','shinythemes','zoo','data.table','ggplot2','ggprism','scales','colorspace','reticulate')
# new.packages <- list.of.packages[!(list.of.packages %in% installed.packages()[,"Package"])]
# if(length(new.packages)) install.packages(new.packages)

# if (!require("BiocManager", quietly = TRUE))
#   install.packages("BiocManager")
#
# BiocManager::install("EBImage")
source('HelperFunctions.R')
sourceGitHubFile('Salus-Discovery','R-LampPrimerAnalyzer','main','LAMPUtils.R')

ui <- fluidPage(

	# Application title
	titlePanel("Rör Prototype Instrument"),

	# Sidebar with a slider input for number of bins
	sidebarLayout(
		sidebarPanel(
			fluidPage(fluidRow(column(3, h4("Target Sequence:")),
							   column(1, textOutput()))),
			tags$textarea(id="Seq", rows=10, cols=60,
						  'atcgaccacttcggcaaccgccgcctgcgtacggtcggcgagctgatccaaaaccagatccgggtcggcatgtcgcggatggagcgggtggtccgggagcggatgaccacccaggacgtggaggcgatcacaccgcagacgttgatcaacatccggccggtggtcgccgcgatcaaggagttcttcggcaccagccagctgagccaattcatgGACcagaacaacccgctgtcggggttgaccCACaagcgccgactgTCGgcgctggggcccggcggtctgtcacgtgagcgtgccgggctggaggtccgcgacgtgcacccgtcgcactacggccggatgtgcccgatcgaaacccctgaggggcccaacatcggtctgatcggctcgctgtcggtgtacgcgcgggtcaacccgttcgggttcatcgaaacgccgtaccgcaaggtggtcgacggcgtggttagcgacgagatcgtgtacctgaccgccgacgagga'
			),
			hr(),
			fluidPage(fluidRow(column(6, numericInput("polyT", "FIP/BIP PolyT-Spacer Length:", 3)),
							   column(6, numericInput("stabilityN", "End Stability Bp's:", 5)))),
			hr(),
			textOutput("Temp1"), textOutput("Temp2"), textOutput("Mag"), textOutput("US")),
		),

	# Show a plot of the generated distribution
	mainPanel(
		tabsetPanel(
			tabPanel("Main",
					 fluidPage(fluidRow(), # Instrument Status Indicators (Not Ready, Ready, Running)
					 		  actionButton("Run"), # Enabled/Disabled Start button
					 		  renderPlot("Plot"), # Real-time plot of data
					 		  tableOutput("ResultsTable"), # Data table of results
					 		  fluidPage(fluidRow(column(2, downloadButton('download',"Download Table")),
					 		  				   column(3, textInput('downloadName',NULL, value='Primer Set 1')),
					 		  				   column(1, h4(".csv")),
					 		  				   column(6, )))
					 ),
					 tabPanel("Images",
					 		 fluidPage(fluidRow(column(4, imageOutput('FAM')),
					 		 				   column(4, imageOutput('TAM')),
					 		 				   column(4, imageOutput('CY5')))
					 		 ),
					 		 tabPanel("Settings",
					 		 )
					 )
			)
		)
	)
)

updatePOPStatus <- function()
{
	if(name=='Temp1')
	{
	return('65')
}

server <- function(input, output, session)
{
	runSettings <- reactiveValues(render=1)
	analysisSettings <- reactiveValues(render=1)
	status <- reactiveValues(render=1)

	# Watch all the inputs and create a ground truth stored version of everything
	observeEvent(list(runSettings,
					  analysisSettings,
					  status,
					  getInputs(channels, 'AUCWindow', input),
					  getInputs(channels, 'MADWindow', input),
					  getInputs(channels, 'RangeWindow', input),
					  getInputs(channels, 'SNRThresh', input)
				 {
		do.call('req', getInputs(sensePrimerNames, 'NTs', input))
		req(settings$seq, settings$FIPlinker, settings$BIPlinker)
		lapply(sensePrimerNames, updateSettingsGroupItem, group='NTs', input=input, settings=settings)
		updateSettingsItem('F1c', revC(settings$NTs$F1, keepCase=T), settings, group='NTs')
		updateSettingsItem('B2', revC(settings$NTs$B2c, keepCase=T), settings, group='NTs')
		updateSettingsItem('B3', revC(settings$NTs$B3c, keepCase=T), settings, group='NTs')
	}))

	# Update Status Panel Items
	output$Temp1 <- renderUI(renderStatus('Well-Temp Targe/Actual:', paste(sig.digits(runSettings$Temp1, nSig=3), getPOPStatus('Temp1'))))
	output$Temp2 <- renderUI(renderStatus('Wax-Temp Targe/Actual:', paste(sig.digits(runSettings$Temp2, nSig=3), getPOPStatus('Temp2'))))
	output$Mag <- renderUI(renderStatus('Mag. Pos.:', getPOPStatus('Mag')))
	output$US <- renderUI(renderStatus('Ultrasonics:', getPOPStatus('US')))
}
