library(shiny)
library(shinyFiles)
library(devtools)
library(curl)
library(shinythemes)
library(zoo)
library(data.table)
library(ggplot2)
library(reticulate)
use_virtualenv(system("pyenv prefix pop_env", intern = TRUE), required = TRUE)

source_python("pop.py")

const <- list(
	camera = list(
		im.w = 1920,
		im.h = 1200,
		gain = 1.0,
		pixel_size_um = 6.5,
		bit_depth = 8,
		file_type = '.bmp'
	),
	channels = c('FAM','TAM','CY5')
)

reactiveValuesToNestedList <- function(rv) {
	lst <- reactiveValuesToList(rv)
	for (name in names(lst)) {
		if (inherits(lst[[name]], "reactivevalues")) {
			lst[[name]] <- reactiveValuesToNestedList(lst[[name]])
		}
	}
	lst
}

##### Settings Functions #####

bind_all_settings <- function(session, input, settings, input_types) {

	for (input_id in names(input_types)) {
		type <- input_types[[input_id]]

		# Skip buttons or unknown types
		if (type %in% c("button", "actionButton")) next

		local({
			id <- input_id
			t  <- type

			# Initialization: set reactiveValue with default widget value
			observe({
				# Only initialize if not already set
				if (is.null(settings[[id]])) {
					settings[[id]] <- input[[id]]
				}
			})

			# Keep reactiveValues in sync with UI changes
			observeEvent(input[[id]], {
				val <- switch(
					t,
					"numeric"         = as.numeric(input[[id]]),
					"checkbox"        = as.logical(input[[id]]),
					"text"            = as.character(input[[id]]),
					"select"          = as.character(input[[id]]),
					"select-multiple" = as.character(input[[id]]),  # returns character vector
					input[[id]]        # fallback
				)
				settings[[id]] <- val
			}, ignoreInit = TRUE)
		})
	}
}



# ---------------------------
# Save settings
# ---------------------------
save_settings <- function(settings, file_path = "user_settings/current.rds") {
	# Convert reactiveValues to list safely
	settings_list <- list()
	for (nm in names(settings)) {
		# Only store simple values
		val <- tryCatch(settings[[nm]], error = function(e) NULL)
		settings_list[[nm]] <- val
	}

	# Add metadata
	settings_list$metadata <- list(
		saved_at = Sys.time(),
		saved_by = Sys.info()["user"]
	)

	# Ensure directory exists
	dir.create(dirname(file_path), recursive = TRUE, showWarnings = FALSE)

	# browser()
	# Save
	saveRDS(settings_list, file_path)
	message("Saved to: ", file_path)
	return(file_path)
}


# ---------------------------
# Load settings
# ---------------------------
load_settings <- function(session, settings, file_path) {
	if (!file.exists(file_path)) return(FALSE)

	lst <- readRDS(file_path)
	for (id in names(lst)) {
		# Skip metadata
		if (id == "metadata") next
		# Update reactiveValues
		settings[[id]] <- lst[[id]]

		# Update UI according to type
		type <- input_types[[id]] %||% "text"  # fallback to text
		switch(type,
			   numeric = updateNumericInput(session, id, value = lst[[id]]),
			   text    = updateTextInput(session, id, value = lst[[id]]),
			   checkbox= updateCheckboxInput(session, id, value = lst[[id]]),
			   select  = updateSelectInput(session, id, selected = lst[[id]]),
			   `select-multiple` = updateSelectInput(session, id, selected = lst[[id]])
		)
	}
	return(TRUE)
}

# reset_to_defaults <- function() {
# 	# Reset each setting to default value
# 	for (name in names(default_settings)) {
# 		if (name %in% names(settings)) {
# 			settings[[name]] <- default_settings[[name]]
# 		}
# 	}
# }

##### Custom UI Objects #####


numericInput2 <- function(inputId, label, value, min = NULL, max = NULL, step = NULL) {
	input_types[[inputId]] <<- "numeric"
	numericInput(inputId, label, value, min, max, step)
}

textInput2 <- function(inputId, label, value = "") {
	input_types[[inputId]] <<- "text"
	textInput(inputId, label, value)
}

selectInput2 <- function(inputId, label, choices, selected = NULL, multiple = FALSE) {
	input_types[[inputId]] <<- if (multiple) "select-multiple" else "select"
	selectInput(inputId, label, choices, selected, multiple)
}

checkboxInput2 <- function(inputId, label, value = FALSE) {
	input_types[[inputId]] <<- "checkbox"
	checkboxInput(inputId, label, value)
}

renderStatus <- function(name, value)
{
	fluidPage({
		fluidRow(style = "height:20px;",
				 column(6, h5(paste(name, ': ', sep=''))),
				 column(4, h5(value)),
				 column(2, h4('✓'))
		)
	})
}

##### General Functions #####

sig.digits <- function(x, nSig=2, trim.spaces=T, trim.zeros=F)
{
	ret <- getPrettyNum(x, sigFigs = nSig, dropTrailingZeros = trim.zeros)

	if(trim.spaces)
	{
		ret <- trimws(ret)
	}

	return(ret)
}

getPrettyNum <- function(x, sigFigs=3, dropTrailingZeros=F)
{
	print(x)
	if(is.null(sigFigs) || is.na(sigFigs))
	{
		ret <- as.character(x)
	}
	else
	{
		ret <- formatC(signif(x,digits=sigFigs), digits=sigFigs,format="fg", flag="#", drop0trailing = dropTrailingZeros)
	}
	if(any(endsWith(ret, '.')))
	{
		for(i in 1:length(ret))
		{
			if(endsWith(ret[i], '.'))
			{
				ret[i] <- substr(ret[i], 1, nchar(ret[i])-1)
			}
		}
	}
	print(ret)
	return(ret)
}
